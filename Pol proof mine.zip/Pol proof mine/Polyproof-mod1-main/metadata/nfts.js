const nfts = [
  {
    name: "0",
    description: "American food that is popular",
    image: "QmdGTxRYAeqYbB1gFVBRUrXpEyiqaVybq4SaHCNPWEFH2f",
  },
  {
    name: "1",
    description: "American food that is popular",
    image: "QmQPdnCwNvuzMSptyRsHqVBTBsrcEfXjhMxnAvDKN8tSze",
  }, 
  {
    name: "2",
    description: "American food that is popular",
    image: "QmQDpXCy596RaaRZQaNYjPZtWD5qA513fJyWp3EZpxxHs9",
  },
  {
    name: "3",
    description: "American food that is popular",
    image: "QmTQBukKjm9MNjmkBYVdJ5JEtZY9fxSLWF8xwQEckzjZ6X",
  },
  {
    name: "4",
    description: "American food that is popular",
    image: "QmTVYFTZFS6zcb1znAvgDSeBFq2LG3EKbkdrwmQmvUg46H",
  },
];

module.exports = nfts;
